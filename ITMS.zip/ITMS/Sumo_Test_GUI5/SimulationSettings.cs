﻿using System;
using System.Collections.Generic;
using System.IO;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Diagnostics;

namespace Sumo_Test_GUI5
{
    public partial class SimulationSettings : Form
    {
        public SimulationSettings()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            /// Setting Delay Tiem And Scheme In Sumo Gui Setting
            XElement xelement = XElement.Load(@"H:\Thesis\Sumo\Examples\Additional\Test7\gui-settings.cfg");

            IEnumerable<XElement> viewsettings = xelement.Elements();

            List<string> menuList = new List<string>();

            int i = 0;

            foreach (var menu in viewsettings)
            {
                try
                {
                    if (i==0)
                    {
                        if (!(string.IsNullOrEmpty(textBox1.Text)))
                        {
                            menuList.Add(menu.Attribute("value").Value = textBox1.Text);
                        }
                        else
                        {
                            menuList.Add(menu.Attribute("value").Value = "300");
                        }
                    }
                    if(i==1)
                    {
                        if (!(string.IsNullOrEmpty(comboBox1.Text)))
                        {
                            menuList.Add(menu.Attribute("name").Value = comboBox1.Text);
                        }
                        else
                        {
                            menuList.Add(menu.Attribute("name").Value = "real world");
                        }
                    }
                    i++;
                }

                catch (Exception)
                { }
            }
            xelement.Save(@"H:\Thesis\Sumo\Examples\Additional\Test7\gui-settings.cfg");
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            /// Reset Diley Time And Scheme In Sumo Gui Setting
            XElement xelement = XElement.Load(@"H:\Thesis\Sumo\Examples\Additional\Test7\gui-settings.cfg");

            IEnumerable<XElement> viewsettings = xelement.Elements();

            List<string> menuList = new List<string>();

            int i = 0;

            foreach (var menu in viewsettings)
            {
                try
                {
                    if (i == 0)
                    {
                        menuList.Add(menu.Attribute("value").Value = "150");
                    }
                    if (i == 1)
                    {
                        menuList.Add(menu.Attribute("name").Value = "real world");
                    }
                    i++;
                }

                catch (Exception)
                { }
            }

            /// Reset Load State Value In Sumo Configuartion File
            xelement.Save(@"H:\Thesis\Sumo\Examples\Additional\Test7\gui-settings.cfg");

            XElement xelement_2 = XElement.Load(@"H:\Thesis\Sumo\Examples\Additional\Test7\test7.sumocfg");

            IEnumerable<XElement> configuration = xelement_2.Elements();

            List<string> menuList2 = new List<string>();
            List<string> subMenuList = new List<string>();

            int j = 0;

            foreach (var menu in configuration)
            {
                try
                {

                    foreach (var submenu in menu.Elements())
                    {
                        if (j == 2)
                        {
                            if ((string.IsNullOrEmpty(comboBox1.Text)))
                            {
                                subMenuList.Add(submenu.Attribute("value").Value = "");
                            }
                        }
                        j++;
                    }          
                }

                catch (Exception)
                { }
            }

            xelement_2.Save(@"H:\Thesis\Sumo\Examples\Additional\Test7\test7.sumocfg");

            /// Weight Setting On Default on Complete Simulation (test7.net.xml)
            XElement xelement_3 = XElement.Load(@"H:\Thesis\Sumo\Examples\Additional\Test7\test7.net.xml");

            IEnumerable<XElement> net = xelement_3.Elements();

            List<string> menuList_3 = new List<string>();
            List<string> subMenuList_3 = new List<string>();

            foreach (var menu in net)
            {
                try
                {
                    if (menu.Attribute("id").Value == "edge2a"  || menu.Attribute("id").Value == "edge2b" ||
                        menu.Attribute("id").Value == "edge5a"  || menu.Attribute("id").Value == "edge5b" ||
                        menu.Attribute("id").Value == "edge6a"  || menu.Attribute("id").Value == "edge6b" ||
                        menu.Attribute("id").Value == "edge8a"  || menu.Attribute("id").Value == "edge8b" ||
                        menu.Attribute("id").Value == "edge11a" || menu.Attribute("id").Value == "edge11b")
                        {
                            foreach (var submenu in menu.Elements())
                            {
                                subMenuList_3.Add(submenu.Attribute("speed").Value = "30");
                            }
                        }
                }

                catch (Exception)
                { }

                xelement_3.Save(@"H:\Thesis\Sumo\Examples\Additional\Test7\test7.net.xml");
            }

            /// Delete Old State Files
            Process process = new Process();
            process.StartInfo.FileName = "cmd.exe";
            process.StartInfo.CreateNoWindow = true;
            process.StartInfo.RedirectStandardInput = true;
            process.StartInfo.RedirectStandardOutput = true;
            process.StartInfo.UseShellExecute = false;
            process.Start();
            process.StandardInput.WriteLine("h:");
            process.StandardInput.WriteLine(@"cd H:\Thesis\Sumo\Examples\Additional\Test7");
            process.StandardInput.WriteLine("Delete.bat");
           /// process.StandardInput.WriteLine("Delete2.bat");
            ///process.StandardInput.WriteLine("Delete3.bat");
            process.StandardInput.Flush();
            process.StandardInput.Close();
            process.WaitForExit();

            MessageBox.Show("Reset Successfully...");
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Main_Form main_form = new Main_Form();
            this.Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void SimulationSettings_Load(object sender, EventArgs e)
        {

        }
    }
}
