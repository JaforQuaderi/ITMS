﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Sumo_Test_GUI5
{
    public partial class Real_Map_Antcolony_Normal : Form
    {
        private System.Windows.Forms.Timer processTimer;
        Process process;

        public Real_Map_Antcolony_Normal()
        {
            InitializeComponent();
        }

        private void Real_Map_Antcolony_Normal_Load(object sender, EventArgs e)
        {
            processTimer = new System.Windows.Forms.Timer();
            processTimer.Tick += new EventHandler(processTimer_Tick);
            processTimer.Interval = 30 * 1000;
        }

        private void processTimer_Tick(object sender, EventArgs e)
        {
            if (process != null)
            {
                foreach (var process2 in Process.GetProcessesByName("sumo-gui"))
                {
                    process2.Kill();
                }
                process = null;

                latestFileAdding();
            }
            sumoGuiFunction();
        }

        public void sumoGuiFunction()
        {
            process = new Process();
            process.StartInfo.FileName = "cmd.exe";
            process.StartInfo.CreateNoWindow = true;
            process.StartInfo.RedirectStandardInput = true;
            process.StartInfo.RedirectStandardOutput = true;
            process.StartInfo.UseShellExecute = false;
            process.Start();
            process.StandardInput.WriteLine("h:");
            process.StandardInput.WriteLine(@"cd H:\Thesis\VS17\Sumo_XML\Thesis\Dhaka Map_Test7 Antcolony");
            process.StandardInput.WriteLine("sumo-gui --routing-algorithm astar --start -c test7.sumocfg");
            process.StandardInput.Flush();
            process.StandardInput.Close();
        }

        public void latestFileAdding()
        {
            string Folder = @"H:\Thesis\VS17\Sumo_XML\Thesis\Dhaka Map_Test7 Antcolony";
            var files = new DirectoryInfo(Folder).GetFiles("test7_*.xml");
            string latestfile = "";

            DateTime lastupdated = DateTime.MinValue;

            foreach (FileInfo file in files)
            {
                if (file.LastWriteTime > lastupdated)
                {
                    lastupdated = file.LastWriteTime;
                    latestfile = file.Name;
                }
            }

            /// Latest File Load, Push, Save
            XElement xelement = XElement.Load(@"H:\Thesis\VS17\Sumo_XML\Thesis\Dhaka Map_Test7 Antcolony\test7.sumocfg");

            IEnumerable<XElement> configuration = xelement.Elements();

            List<string> menuList = new List<string>();
            List<string> subMenuList = new List<string>();

            int i = 0;

            foreach (var menu in configuration)
            {
                foreach (var submenu in menu.Elements())
                {
                    if (i == 2)
                    {
                        subMenuList.Add(submenu.Attribute("value").Value = latestfile);
                        break;
                    }
                    i++;
                }
                break;
            }
            xelement.Save(@"H:\Thesis\VS17\Sumo_XML\Thesis\Dhaka Map_Test7 Antcolony\test7.sumocfg");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Real_Map_Antcolony_Simulation real_rmap_antcolony_simulation = new Real_Map_Antcolony_Simulation();
            real_rmap_antcolony_simulation.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            foreach (var process_2 in Process.GetProcessesByName("sumo-gui"))
            {
                process_2.Kill();
                processTimer.Enabled = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            processTimer.Start();
        }
    }
}
