﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sumo_Test_GUI5
{
    public partial class Real_Map_Deafult_Simulation : Form
    {
        public Real_Map_Deafult_Simulation()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Real_Map_Default_Normal real_map_default_normal = new Real_Map_Default_Normal();
            real_map_default_normal.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Real_Map_Default_Faster real_map_default_faster = new Real_Map_Default_Faster();
            real_map_default_faster.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Real_Map real_map = new Real_Map();
            real_map.Show();
            this.Hide();
        }
    }
}
