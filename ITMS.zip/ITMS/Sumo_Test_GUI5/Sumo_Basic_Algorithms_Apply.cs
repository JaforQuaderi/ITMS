﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sumo_Test_GUI5
{
    public partial class Sumo_Basic_Algorithms_Apply : Form
    {
        public string algorithm;

        public Sumo_Basic_Algorithms_Apply()
        {
            InitializeComponent();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Sumo_Antcolony sumo_antcolony = new Sumo_Antcolony();
            sumo_antcolony.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            algorithm = "dijkstra";
            sumoAlgorithms_Normal(algorithm);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            algorithm = "astar";
            sumoAlgorithms_Normal(algorithm);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            algorithm = "CH";
            sumoAlgorithms_Normal(algorithm);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            algorithm = "CHWrapper";
            sumoAlgorithms_Normal(algorithm);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            algorithm = "dijkstra";
            sumoAlgorithms_Faster(algorithm);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            algorithm = "astar";
            sumoAlgorithms_Faster(algorithm);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            algorithm = "CH";
            sumoAlgorithms_Faster(algorithm);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            algorithm = "CHWrapper";
            sumoAlgorithms_Faster(algorithm);
        }

        public void sumoAlgorithms_Normal(string algorithm)
        {
            Process process_normal;

            process_normal = new Process();
            process_normal.StartInfo.FileName = "cmd.exe";
            process_normal.StartInfo.CreateNoWindow = true;
            process_normal.StartInfo.RedirectStandardInput = true;
            process_normal.StartInfo.RedirectStandardOutput = true;
            process_normal.StartInfo.UseShellExecute = false;
            process_normal.Start();
            process_normal.StandardInput.WriteLine("h:");
            process_normal.StandardInput.WriteLine(@"cd H:\Thesis\VS17\Sumo_XML\Thesis\Sumo Algorithm (Dif_A_Wr_CHWr) Normal");
            process_normal.StandardInput.WriteLine("sumo-gui --routing-algorithm " + algorithm + " --start -c test7.sumocfg");
            process_normal.StandardInput.Flush();
            process_normal.StandardInput.Close();
            process_normal.WaitForExit();
        }

        public void sumoAlgorithms_Faster(string algorithm)
        {
            Process process_faster;

            process_faster = new Process();
            process_faster.StartInfo.FileName = "cmd.exe";
            process_faster.StartInfo.CreateNoWindow = true;
            process_faster.StartInfo.RedirectStandardInput = true;
            process_faster.StartInfo.RedirectStandardOutput = true;
            process_faster.StartInfo.UseShellExecute = false;
            process_faster.Start();
            process_faster.StandardInput.WriteLine("h:");
            process_faster.StandardInput.WriteLine(@"cd H:\Thesis\VS17\Sumo_XML\Thesis\Sumo Algorithm (Dif_A_Wr_CHWr) Faster");
            process_faster.StandardInput.WriteLine("sumo-gui --routing-algorithm " + algorithm + " --start -c test7.sumocfg");
            process_faster.StandardInput.Flush();
            process_faster.StandardInput.Close();
            process_faster.WaitForExit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            foreach (var process_close in Process.GetProcessesByName("sumo-gui"))
            {
                process_close.Kill();
            }
        }
    }
}
