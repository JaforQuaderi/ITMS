﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Sumo_Test_GUI5
{
    public partial class Real_Map : Form
    {
        public Real_Map()
        {
            InitializeComponent();
        }

        private void Real_Map_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Real_Map_Deafult_Simulation real_map_deafult_simulation = new Real_Map_Deafult_Simulation();
            real_map_deafult_simulation.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Real_Map_Antcolony_Simulation real_map_antcolony_simulation = new Real_Map_Antcolony_Simulation();
            real_map_antcolony_simulation.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Sumo_Antcolony sumo_antcolony = new Sumo_Antcolony();
            sumo_antcolony.Show();
            this.Hide();
        }
    }
}
