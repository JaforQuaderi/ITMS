python3 infer.py --humidity 50 --peekhour 30 --rainfall 0\
 --temperature 20 --wind 5 --road_status 0 --road_construction 0\
 --road_accident 0 --vehicle_speed 30
