
# coding: utf-8

# In[ ]:


import argparse
import infer_fuzzy
import numpy as np
import keras
from keras.models import Sequential
from keras.layers import Dense, Dropout


# In[ ]:


parser = argparse.ArgumentParser(description='')

parser.add_argument('--humidity', type=int, help='Humidity value.')
parser.add_argument('--peekhour', type=int, help='Peek hour value.')
parser.add_argument('--rainfall', type=float, help='Rain fall value.')
parser.add_argument('--temperature', type=float, help='Temprature value')
parser.add_argument('--wind', type=float, help='Wind value.')
parser.add_argument('--road_status', type=int, help='0 if road is clear, otherwise 1.')
parser.add_argument('--road_construction', type=int, help='0 if no road repair is going on,'
                                                          '1 if repair work is medium,'
                                                          'otherwise 2, for heavy work.')
parser.add_argument('--road_accident', type=int, help='0 if no road accidnt, otherwise,'
                                                       '1 for road accident.')
parser.add_argument('--vehicle_speed', type=int, help='Vehicle speed.')

args = parser.parse_args()


# In[ ]:


model = Sequential()
model.add(Dense(35, activation='relu', input_shape=(28, )))
model.add(Dropout(0.25))
model.add(Dense(11, activation='softmax'))
model.compile(loss=keras.losses.categorical_crossentropy, 
             optimizer=keras.optimizers.Adam(), metrics=['accuracy'])


# In[ ]:


filepath="weights/weights.best.hdf5"
model.load_weights(filepath)


# In[ ]:


mem = infer_fuzzy.predictFuzzMem(args.humidity, args.peekhour, args.rainfall, 
								args.temperature, args.wind, args.road_status, 
                     			args.road_construction, args.road_accident, args.vehicle_speed)
mem = mem.reshape(1, len(mem))

#mem = infer_fuzzy.predictFuzzMem(args.humidity, args.peekhour, args.rainfall, 
#								args.temperature, args.wind)
#mem = mem.reshape(1, len(mem))

with open('out.txt', 'w') as f:
	f.write(str(np.argmax(model.predict(mem))))