import numpy as np
from numpy import loadtxt
import skfuzzy as fuzz


# store cluster centers for features
hcntr = np.array(loadtxt("data/humidity_cntr.txt", comments="#", delimiter=",", unpack=False))
pcntr = np.array(loadtxt("data/peekhour_cntr.txt", comments="#", delimiter=",", unpack=False))
rcntr = np.array(loadtxt("data/rainfall_cntr.txt", comments="#", delimiter=",", unpack=False))
tcntr = np.array(loadtxt("data/temp_cntr.txt", comments="#", delimiter=",", unpack=False))
wcntr = np.array(loadtxt("data/wind_cntr.txt", comments="#", delimiter=",", unpack=False))


def predict_humidity(values):
    # value -numpy array
    xpts = np.zeros(len(values))
    data = np.vstack((values, xpts))
    u, u0, d, jm, p, fpc = fuzz.cluster.cmeans_predict(
        data, hcntr, 1.5, error=0.0005, maxiter=1000)
    cluster_membership = np.argmax(u, axis=0)
    
    return cluster_membership



def predict_peekhour(values):
    xpts = np.zeros(len(values))
    data = np.vstack((values, xpts))
    u, u0, d, jm, p, fpc = fuzz.cluster.cmeans_predict(
        data, pcntr, 1.5, error=0.0005, maxiter=1000)
    cluster_membership = np.argmax(u, axis=0)
    
    return cluster_membership




def predict_rainfall(values):
    xpts = np.zeros(len(values))
    data = np.vstack((values, xpts))
    u, u0, d, jm, p, fpc = fuzz.cluster.cmeans_predict(
        data, rcntr, 1.5, error=0.0005, maxiter=1000)
    cluster_membership = np.argmax(u, axis=0)
    
    return cluster_membership



def predict_temp(values):
    xpts = np.zeros(len(values))
    data = np.vstack((values, xpts))
    u, u0, d, jm, p, fpc = fuzz.cluster.cmeans_predict(
        data, tcntr, 1.5, error=0.0005, maxiter=1000)
    cluster_membership = np.argmax(u, axis=0)
    
    return cluster_membership



def predict_wind(values):
    xpts = np.zeros(len(values))
    data = np.vstack((values, xpts))
    u, u0, d, jm, p, fpc = fuzz.cluster.cmeans_predict(
        data, wcntr, 1.5, error=0.0005, maxiter=1000)
    cluster_membership = np.argmax(u, axis=0)
    
    return cluster_membership