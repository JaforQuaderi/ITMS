﻿using System;
using System.Collections.Generic;
using System.IO;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Diagnostics;

namespace Sumo_Test_GUI5
{
    public partial class Edge8_RoadStatus : Form
    {
        //Send Road Value To Main Form
        public static string passingText;

        ///Send Flag Value To Main Form
        public static int passingFlag;

        public Edge8_RoadStatus()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Main_Form main_form = new Main_Form();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            passingFlag = 0;
            /// Checking Road Status (comboBox1)
            int roadStatusValue = 0;

            if (comboBox1.Text == "busy")
            {
                roadStatusValue = 1;
            }
            else
            {
                roadStatusValue = 0;
            }

            /// Latest File Adding
            string Folder = @"H:\Thesis\Sumo\Examples\Additional\Test7";
            var files = new DirectoryInfo(Folder).GetFiles("test7_*.xml");
            string latestfile = "";

            DateTime lastupdated = DateTime.MinValue;

            foreach (FileInfo file in files)
            {
                if (file.LastWriteTime > lastupdated)
                {
                    lastupdated = file.LastWriteTime;
                    latestfile = file.Name;
                }
            }

            /// Latest File Load, Push, Save
            XElement xelement = XElement.Load(@"H:\Thesis\Sumo\Examples\Additional\Test7\test7.sumocfg");

            IEnumerable<XElement> configuration = xelement.Elements();

            List<string> menuList = new List<string>();
            List<string> subMenuList = new List<string>();

            int i = 0;

            foreach (var menu in configuration)
            {
                foreach (var submenu in menu.Elements())
                {
                    if (i == 2)
                    {
                        subMenuList.Add(submenu.Attribute("value").Value = latestfile);
                        break;
                    }
                    i++;
                }
                break;
            }
            xelement.Save(@"H:\Thesis\Sumo\Examples\Additional\Test7\test7.sumocfg");


            /// Input Textbox Value and Creating out.txt
            Process process = new Process();
            process.StartInfo.FileName = "cmd.exe";
            process.StartInfo.CreateNoWindow = true;
            process.StartInfo.RedirectStandardInput = true;
            process.StartInfo.RedirectStandardOutput = true;
            process.StartInfo.UseShellExecute = false;
            process.Start();
            process.StandardInput.WriteLine("h:");
            process.StandardInput.WriteLine(@"cd H:\Thesis\NeuroFuzzy");
            ///process.StandardInput.WriteLine("python infer.py --humidity 50 --peekhour 40 --rainfall 0 --temperature 25 --wind 35 --road_status 0 --road_construction 0 --road_accident 0 --vehicle_speed 85");
            ///process.StandardInput.WriteLine("python infer.py --humidity " + textBox1.Text + " --peekhour " + textBox2.Text + " --rainfall " + textBox3.Text + " --temperature " + textBox4.Text + " --wind " + textBox5.Text + " --road_status " + textBox6.Text + " --road_construction " + textBox7.Text + " --road_accident " + textBox8.Text + " --vehicle_speed " + textBox5.Text + "");
            process.StandardInput.WriteLine("python infer.py --humidity 50 --peekhour 30 --rainfall 0 --temperature 25 --wind 35 --road_status " + roadStatusValue + " --road_construction 0 --road_accident 0 --vehicle_speed 30");
            process.StandardInput.Flush();
            process.StandardInput.Close();
            process.WaitForExit();


            /// Show out.Txt Value
            string weight;
            string speed;
            string line;
            string file2 = "H:/Thesis/NeuroFuzzy/out.txt";
            StreamReader myFile = new StreamReader(file2);
            while (myFile.EndOfStream == false)
            {
                line = myFile.ReadLine();
                weight = line;

                if (weight == "0")
                {
                    speed = "40";
                }
                else if (weight == "1")
                {
                    speed = "37";
                    textBox10.Text = speed;
                }
                else if (weight == "2")
                {
                    speed = "33";
                    textBox10.Text = speed;
                }
                else if (weight == "3")
                {
                    speed = "30";
                    textBox10.Text = speed;
                }
                else if (weight == "4")
                {
                    speed = "25";
                    textBox10.Text = speed;
                }
                else if (weight == "5")
                {
                    speed = "21";
                    textBox10.Text = speed;
                }
                else if (weight == "6")
                {
                    speed = "18";
                    textBox10.Text = speed;
                }
                else if (weight == "7")
                {
                    speed = "15";
                    textBox10.Text = speed;
                }
                else if (weight == "8")
                {
                    speed = "12";
                    textBox10.Text = speed;
                }
                else if (weight == "9")
                {
                    speed = "8";
                    textBox10.Text = speed;
                }
                else if (weight == "10")
                {
                    speed = "5";
                    textBox10.Text = speed;
                }
            }
            myFile.Close();

            /// Weight Setting On Edge And Lane
            XElement xelement_2 = XElement.Load(@"H:\Thesis\Sumo\Examples\Additional\Test7\test7.net.xml");

            IEnumerable<XElement> net = xelement_2.Elements();

            List<string> menuList_2 = new List<string>();
            List<string> subMenuList_2 = new List<string>();

            foreach (var menu in net)
            {
                try
                {
                    foreach (string edge in checkedListBox1.CheckedItems)
                    {
                        if (edge == "all")  /// Edge all
                        {
                            if (menu.Attribute("id").Value == "edge8a" || menu.Attribute("id").Value == "edge8b")
                            {
                                foreach (var submenu in menu.Elements())
                                {
                                    foreach (string lane in checkedListBox2.CheckedItems)
                                    {
                                        if (lane == "all")   /// Edge all --- Lane all
                                        {
                                            if (submenu.Attribute("index").Value == "0" ||
                                                submenu.Attribute("index").Value == "1")
                                            {
                                                subMenuList_2.Add(submenu.Attribute("speed").Value = textBox10.Text);
                                            }
                                        }
                                        else if (submenu.Attribute("index").Value == lane)/// Edge all --- Lane (0/1)
                                        {
                                            subMenuList_2.Add(submenu.Attribute("speed").Value = textBox10.Text);
                                        }
                                    }
                                }
                            }
                        }

                        else if (menu.Attribute("id").Value == edge) /// Edge (0/1)
                        {
                            foreach (var submenu in menu.Elements())
                            {
                                foreach (string lane in checkedListBox2.CheckedItems)
                                {
                                    if (lane == "all")  /// Edge (0/1) --- Lane all
                                    {
                                        if (submenu.Attribute("index").Value == "0" ||
                                            submenu.Attribute("index").Value == "1")
                                        {
                                            subMenuList_2.Add(submenu.Attribute("speed").Value = textBox10.Text);
                                        }
                                    }
                                    else if (submenu.Attribute("index").Value == lane)  /// Edge (0/1) --- Lane (0/1)
                                    {
                                        subMenuList_2.Add(submenu.Attribute("speed").Value = textBox10.Text);
                                    }
                                }
                            }
                        }
                    }
                }

                catch (Exception)
                { }

                xelement_2.Save(@"H:\Thesis\Sumo\Examples\Additional\Test7\test7.net.xml");
            }

            passingFlag = 1;
            passingText = textBox10.Text;
            ///Main_Form main_form = new Main_Form();
            ///this.Hide();

            ///Sumo-Gui Automatic Closing And Starting Load File
            foreach (var process_2 in Process.GetProcessesByName(label14.Text))
            {
                process_2.Kill();
            }
            Process process3 = new Process();
            process3.StartInfo.FileName = "cmd.exe";
            process3.StartInfo.CreateNoWindow = true;
            process3.StartInfo.RedirectStandardInput = true;
            process3.StartInfo.RedirectStandardOutput = true;
            process3.StartInfo.UseShellExecute = false;
            process3.Start();
            process3.StandardInput.WriteLine("h:");
            process3.StandardInput.WriteLine(@"cd H:\Thesis\Sumo\Examples\Additional\Test7");
            ///process3.StandardInput.WriteLine("sumo-gui --start -c test7.sumocfg");
            process3.StandardInput.WriteLine("sumo-gui --routing-algorithm astar --start -c test7.sumocfg");
            process3.StandardInput.Flush();
            process3.StandardInput.Close();
            process3.WaitForExit();
        }

        private void Edge8_RoadStatus_Load(object sender, EventArgs e)
        {

        }
    }
}
