﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sumo_Test_GUI5
{
    public partial class Sample_Map_Antcolony : Form
    {
        public Sample_Map_Antcolony()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Sample_Map_Antcolony_Normal sample_map_antcolony_normal = new Sample_Map_Antcolony_Normal();
            sample_map_antcolony_normal.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Sample_Map_Antcolony_Faster sample_map_antcolony_faster = new Sample_Map_Antcolony_Faster();
            sample_map_antcolony_faster.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Sumo_Antcolony sumo_antcolony = new Sumo_Antcolony();
            sumo_antcolony.Show();
            this.Hide();
        }
   
        private void Sample_Map_Antcolony_Load(object sender, EventArgs e)
        {

        }
    }
}
