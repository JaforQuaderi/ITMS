﻿using System;
using System.Collections.Generic;
using System.IO;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Diagnostics;
using System.Globalization;
using System.Threading;

namespace Sumo_Test_GUI5
{
    public partial class Main_Form : Form
    {
        private System.Windows.Forms.Timer processTimer;
        Process process_timer;
        int countSumo = 1;
        int countChange = 0;


        public string row1_edge2;
        public string row2_edge2;
        public string row3_edge2;
        public string row1_edge5;
        public string row2_edge5;
        public string row3_edge5;
        public string row1_edge8;
        public string row2_edge8;
        public string row3_edge8;
        public string row1_edge11;
        public string row2_edge11;
        public string row3_edge11;



        public Main_Form()
        {
            InitializeComponent();
        }

        ///*********
        private void Main_Form_Load(object sender, EventArgs e)
        {
            processTimer = new System.Windows.Forms.Timer();
            processTimer.Tick += new EventHandler(processTimer_Tick);
            processTimer.Interval = 20 * 1000; ///Timer 20 Seconds
        }

        private void processTimer_Tick(object sender, EventArgs e)
        {
            var item = checkedListBox1.CheckedIndices;

            if (process_timer != null)
            {
                foreach (var process_close in Process.GetProcessesByName("sumo-gui"))
                {
                    process_close.Kill();
                }
                process_timer = null;

                if(countChange > 0)
                {
                    if (textBox10.Text == "30")
                    {
                        baseAntcolony();
                    }
                    else
                    {
                        if(item.Count == 1)
                        {
                            if (checkedListBox1.Text == "edge2")
                            {
                                combinedEdgeAntColony("edge2");
                            }
                            else if (checkedListBox1.Text == "edge5")
                            {
                                combinedEdgeAntColony("edge5");
                            }
                            else if (checkedListBox1.Text == "edge8")
                            {
                                combinedEdgeAntColony("edge8");
                            }
                            else if (checkedListBox1.Text == "edge11")
                            {
                                combinedEdgeAntColony("edge11");
                            }
                        }
                                           
                        else if(item.Count == 2)
                        {
                            if (checkedListBox1.Text == "edge2" || checkedListBox1.Text == "edge5")
                            {
                                combinedEdgeAntColony_Edge2_Edge5("edge2", "edge5");
                            }
                            else if (checkedListBox1.Text == "edge2" || checkedListBox1.Text == "edge8")
                            {
                                combinedEdgeAntColony_Edge2_Edge8("edge2", "edge8");
                            }
                            else if (checkedListBox1.Text == "edge2" || checkedListBox1.Text == "edge11")
                            {
                                combinedEdgeAntColony_Edge2_Edge11("edge2", "edge11");
                            }
                            else if (checkedListBox1.Text == "edge5" || checkedListBox1.Text == "edge8")
                            {
                                combinedEdgeAntColony_Edge5_Edge8("edge5", "edge8");
                            }
                            else if (checkedListBox1.Text == "edge5" || checkedListBox1.Text == "edge11")
                            {
                                combinedEdgeAntColony_Edge5_Edge11("edge5", "edge11");
                            }
                            else if (checkedListBox1.Text == "edge8" || checkedListBox1.Text == "edge11")
                            {
                                combinedEdgeAntColony_Edge8_Edge11("edge8", "edge11");
                            }
                        }

                        else if(item.Count == 3)
                        {
                            if (checkedListBox1.Text == "edge2" || checkedListBox1.Text == "edge5" || checkedListBox1.Text == "edge8")
                            {
                                combinedEdgeAntColony_Edge2_Edge5_Edge8("edge2", "edge5", "edge8");
                            }
                            else if (checkedListBox1.Text == "edge2" || checkedListBox1.Text == "edge8" || checkedListBox1.Text == "edge11")
                            {
                                combinedEdgeAntColony_Edge2_Edge8_Edge11("edge2", "edge8", "edge11");
                            }
                            else if (checkedListBox1.Text == "edge5" || checkedListBox1.Text == "edge8" || checkedListBox1.Text == "edge11")
                            {
                                combinedEdgeAntColony_Edge5_Edge8_Edge11("edge5", "edge8", "edge11");
                            }
                        }

                        else if(item.Count == 4)
                        {
                            if (checkedListBox1.Text == "edge2" || checkedListBox1.Text == "edge5" || checkedListBox1.Text == "edge8" || checkedListBox1.Text == "edge11")
                            {
                                combinedEdgeAntColony_Edge2_Edge5_Edge8_Edge11("edge2", "edge5", "edge8", "edge11");
                            }
                        }
                    }
                }

                /// Edge2 Road Accident Value Set
                else if (Edge2_RoadAccident.passingFlag == 1)
                {
                    if (Edge2_RoadAccident.passingText == "30")
                    {
                        baseAntcolony();
                    }
                    else
                    {
                        if (countSumo == 1 || countSumo == 4 || countSumo == 7 || countSumo == 10 || countSumo == 13 || countSumo == 16 || countSumo == 19)
                        {
                            edgeAntColony(Edge2_RoadAccident.passingText, "50", "40", "50");
                        }

                        if (countSumo == 2 || countSumo == 5 || countSumo == 8 || countSumo == 11 || countSumo == 14 || countSumo == 17 || countSumo == 20)
                        {
                            edgeAntColony(Edge2_RoadAccident.passingText, "100", "80", "100");
                        }

                        if (countSumo == 3 || countSumo == 6 || countSumo == 9 || countSumo == 12 || countSumo == 15 || countSumo == 18 || countSumo == 21)
                        {
                            edgeAntColony(Edge2_RoadAccident.passingText, "15", "100", "15");
                        }
                    }
                }

                /// Edge2 Road Construction Value Set
                else if (Edge2_RoadConstruction.passingFlag == 1)
                {
                    if (Edge2_RoadConstruction.passingText == "30")
                    {
                        baseAntcolony();
                    }
                    else
                    {
                        if (countSumo == 1 || countSumo == 4 || countSumo == 7 || countSumo == 10 || countSumo == 13 || countSumo == 16 || countSumo == 19)
                        {
                            edgeAntColony(Edge2_RoadConstruction.passingText, "50", "40", "50");
                        }

                        if (countSumo == 2 || countSumo == 5 || countSumo == 8 || countSumo == 11 || countSumo == 14 || countSumo == 17 || countSumo == 20)
                        {
                            edgeAntColony(Edge2_RoadConstruction.passingText, "100", "80", "100");
                        }

                        if (countSumo == 3 || countSumo == 6 || countSumo == 9 || countSumo == 12 || countSumo == 15 || countSumo == 18 || countSumo == 21)
                        {
                            edgeAntColony(Edge2_RoadConstruction.passingText, "15", "100", "15");
                        }
                    }
                }

                /// Edge2 Road Status Value Set
                else if (Edge2_RoadStatus.passingFlag == 1)
                {
                    if (Edge2_RoadStatus.passingText == "30")
                    {
                        baseAntcolony();
                    }
                    else
                    {
                        if (countSumo == 1 || countSumo == 4 || countSumo == 7 || countSumo == 10 || countSumo == 13 || countSumo == 16 || countSumo == 19)
                        {
                            edgeAntColony(Edge2_RoadStatus.passingText, "50", "40", "50");
                        }

                        if (countSumo == 2 || countSumo == 5 || countSumo == 8 || countSumo == 11 || countSumo == 14 || countSumo == 17 || countSumo == 20)
                        {
                            edgeAntColony(Edge2_RoadStatus.passingText, "100", "80", "100");
                        }

                        if (countSumo == 3 || countSumo == 6 || countSumo == 9 || countSumo == 12 || countSumo == 15 || countSumo == 18 || countSumo == 21)
                        {
                            edgeAntColony(Edge2_RoadStatus.passingText, "15", "100", "15");
                        }
                    }
                }

                /// Edge5 Road Accident Value Set
                else if (Edge5_RoadAccident.passingFlag == 1)
                {
                    if (Edge5_RoadAccident.passingText == "30")
                    {
                        baseAntcolony();
                    }
                    else
                    {
                        if (countSumo == 1 || countSumo == 4 || countSumo == 7 || countSumo == 10 || countSumo == 13 || countSumo == 16 || countSumo == 19)
                        {
                            edgeAntColony("120", Edge5_RoadAccident.passingText, "40", "50");
                        }

                        if (countSumo == 2 || countSumo == 5 || countSumo == 8 || countSumo == 11 || countSumo == 14 || countSumo == 17 || countSumo == 20)
                        {
                            edgeAntColony("50", Edge5_RoadAccident.passingText, "80", "100");
                        }

                        if (countSumo == 3 || countSumo == 6 || countSumo == 9 || countSumo == 12 || countSumo == 15 || countSumo == 18 || countSumo == 21)
                        {
                            edgeAntColony("5", Edge5_RoadAccident.passingText, "100", "15");
                        }
                    }
                }

                /// Edge5 Road Construction Value Set
                else if (Edge5_RoadConstruction.passingFlag == 1)
                {
                    if (Edge5_RoadConstruction.passingText == "30")
                    {
                        baseAntcolony();
                    }
                    else
                    {
                        if (countSumo == 1 || countSumo == 4 || countSumo == 7 || countSumo == 10 || countSumo == 13 || countSumo == 16 || countSumo == 19)
                        {
                            edgeAntColony("120", Edge5_RoadConstruction.passingText, "40", "50");
                        }

                        if (countSumo == 2 || countSumo == 5 || countSumo == 8 || countSumo == 11 || countSumo == 14 || countSumo == 17 || countSumo == 20)
                        {
                            edgeAntColony("50", Edge5_RoadConstruction.passingText, "80", "100");
                        }

                        if (countSumo == 3 || countSumo == 6 || countSumo == 9 || countSumo == 12 || countSumo == 15 || countSumo == 18 || countSumo == 21)
                        {
                            edgeAntColony("5", Edge5_RoadConstruction.passingText, "100", "15");
                        }
                    }
                }

                /// Edge5 Road Status Value Set
                else if (Edge5_RoadStatus.passingFlag == 1)
                {
                    if (Edge5_RoadStatus.passingText == "30")
                    {
                        baseAntcolony();
                    }
                    else
                    {
                        if (countSumo == 1 || countSumo == 4 || countSumo == 7 || countSumo == 10 || countSumo == 13 || countSumo == 16 || countSumo == 19)
                        {
                            edgeAntColony("120", Edge5_RoadStatus.passingText, "40", "50");
                        }

                        if (countSumo == 2 || countSumo == 5 || countSumo == 8 || countSumo == 11 || countSumo == 14 || countSumo == 17 || countSumo == 20)
                        {
                            edgeAntColony("50", Edge5_RoadStatus.passingText, "80", "100");
                        }

                        if (countSumo == 3 || countSumo == 6 || countSumo == 9 || countSumo == 12 || countSumo == 15 || countSumo == 18 || countSumo == 21)
                        {
                            edgeAntColony("5", Edge5_RoadStatus.passingText, "100", "15");
                        }
                    }
                }

                /// Edge8 Road Accident Value Set
                else if (Edge8_RoadAccident.passingFlag == 1)
                {
                    if (Edge8_RoadAccident.passingText == "30")
                    {
                        baseAntcolony();
                    }
                    else
                    {
                        if (countSumo == 1 || countSumo == 4 || countSumo == 7 || countSumo == 10 || countSumo == 13 || countSumo == 16 || countSumo == 19)
                        {
                            edgeAntColony("120", "50", Edge8_RoadAccident.passingText, "50");
                        }

                        if (countSumo == 2 || countSumo == 5 || countSumo == 8 || countSumo == 11 || countSumo == 14 || countSumo == 17 || countSumo == 20)
                        {
                            edgeAntColony("50", "100", Edge8_RoadAccident.passingText, "100");
                        }

                        if (countSumo == 3 || countSumo == 6 || countSumo == 9 || countSumo == 12 || countSumo == 15 || countSumo == 18 || countSumo == 21)
                        {
                            edgeAntColony("5", "15", Edge8_RoadAccident.passingText, "15");
                        }
                    }
                }

                /// Edge8 Road Construction Value Set
                else if (Edge8_RoadConstruction.passingFlag == 1)
                {
                    if (Edge8_RoadConstruction.passingText == "30")
                    {
                        baseAntcolony();
                    }
                    else
                    {
                        if (countSumo == 1 || countSumo == 4 || countSumo == 7 || countSumo == 10 || countSumo == 13 || countSumo == 16 || countSumo == 19)
                        {
                            edgeAntColony("120", "50", Edge8_RoadConstruction.passingText, "50");
                        }

                        if (countSumo == 2 || countSumo == 5 || countSumo == 8 || countSumo == 11 || countSumo == 14 || countSumo == 17 || countSumo == 20)
                        {
                            edgeAntColony("50", "100", Edge8_RoadConstruction.passingText, "100");
                        }

                        if (countSumo == 3 || countSumo == 6 || countSumo == 9 || countSumo == 12 || countSumo == 15 || countSumo == 18 || countSumo == 21)
                        {
                            edgeAntColony("5", "15", Edge8_RoadConstruction.passingText, "15");
                        }
                    }
                }

                /// Edge8 Road Status Value Set
                else if (Edge8_RoadStatus.passingFlag == 1)
                {
                    if (Edge8_RoadStatus.passingText == "30")
                    {
                        baseAntcolony();
                    }
                    else
                    {
                        if (countSumo == 1 || countSumo == 4 || countSumo == 7 || countSumo == 10 || countSumo == 13 || countSumo == 16 || countSumo == 19)
                        {
                            edgeAntColony("120", "50", Edge5_RoadStatus.passingText, "50");
                        }

                        if (countSumo == 2 || countSumo == 5 || countSumo == 8 || countSumo == 11 || countSumo == 14 || countSumo == 17 || countSumo == 20)
                        {
                            edgeAntColony("50", "100", Edge5_RoadStatus.passingText, "100");
                        }

                        if (countSumo == 3 || countSumo == 6 || countSumo == 9 || countSumo == 12 || countSumo == 15 || countSumo == 18 || countSumo == 21)
                        {
                            edgeAntColony("5", "15", Edge5_RoadStatus.passingText, "15");
                        }
                    }
                }

                /// Edge11 Road Accident Value Set
                else if (Edge11_RoadAccident.passingFlag == 1)
                {
                    if (Edge11_RoadAccident.passingText == "30")
                    {
                        baseAntcolony();
                    }
                    else
                    {
                        if (countSumo == 1 || countSumo == 4 || countSumo == 7 || countSumo == 10 || countSumo == 13 || countSumo == 16 || countSumo == 19)
                        {
                            edgeAntColony("120", "50", "40", Edge8_RoadAccident.passingText);
                        }

                        if (countSumo == 2 || countSumo == 5 || countSumo == 8 || countSumo == 11 || countSumo == 14 || countSumo == 17 || countSumo == 20)
                        {
                            edgeAntColony("50", "100", "80", Edge8_RoadAccident.passingText);
                        }

                        if (countSumo == 3 || countSumo == 6 || countSumo == 9 || countSumo == 12 || countSumo == 15 || countSumo == 18 || countSumo == 21)
                        {
                            edgeAntColony("5", "15", "100", Edge8_RoadAccident.passingText);
                        }
                    }
                }

                /// Edge11 Road Construction Value Set
                else if (Edge11_RoadConstruction.passingFlag == 1)
                {
                    if (Edge11_RoadConstruction.passingText == "30")
                    {
                        baseAntcolony();
                    }
                    else
                    {
                        if (countSumo == 1 || countSumo == 4 || countSumo == 7 || countSumo == 10 || countSumo == 13 || countSumo == 16 || countSumo == 19)
                        {
                            edgeAntColony("120", "50", "40", Edge11_RoadConstruction.passingText);
                        }

                        if (countSumo == 2 || countSumo == 5 || countSumo == 8 || countSumo == 11 || countSumo == 14 || countSumo == 17 || countSumo == 20)
                        {
                            edgeAntColony("50", "100", "80", Edge11_RoadConstruction.passingText);
                        }

                        if (countSumo == 3 || countSumo == 6 || countSumo == 9 || countSumo == 12 || countSumo == 15 || countSumo == 18 || countSumo == 21)
                        {
                            edgeAntColony("5", "15", "100", Edge11_RoadConstruction.passingText);
                        }
                    }
                }

                /// Edge11 Road Status Value Set
                else if (Edge11_RoadStatus.passingFlag == 1)
                {
                    if (Edge11_RoadStatus.passingText == "30")
                    {
                        baseAntcolony();
                    }
                    else
                    {
                        if (countSumo == 1 || countSumo == 4 || countSumo == 7 || countSumo == 10 || countSumo == 13 || countSumo == 16 || countSumo == 19)
                        {
                            edgeAntColony("120", "50", "40", Edge11_RoadStatus.passingText);
                        }

                        if (countSumo == 2 || countSumo == 5 || countSumo == 8 || countSumo == 11 || countSumo == 14 || countSumo == 17 || countSumo == 20)
                        {
                            edgeAntColony("50", "100", "80", Edge11_RoadStatus.passingText);
                        }

                        if (countSumo == 3 || countSumo == 6 || countSumo == 9 || countSumo == 12 || countSumo == 15 || countSumo == 18 || countSumo == 21)
                        {
                            edgeAntColony("5", "15", "100", Edge11_RoadStatus.passingText);
                        }
                    }
                }

                else
                {
                    baseAntcolony();
                }

                countSumo++;

                latestFileAdding();
            }
            sumoGuiFunction();
        }

        /// When Speed =  30, That Antcolony For Edge2, Edge5, Edge8, Edge 11
        public void baseAntcolony()
        {
            if (countSumo == 1 || countSumo == 4 || countSumo == 7 || countSumo == 10 || countSumo == 13 || countSumo == 16 || countSumo == 19)
            {
                edgeAntColony("120", "50", "40", "50");
            }

            if (countSumo == 2 || countSumo == 5 || countSumo == 8 || countSumo == 11 || countSumo == 14 || countSumo == 17 || countSumo == 20)
            {
                edgeAntColony("50", "100", "80", "100");
            }

            if (countSumo == 3 || countSumo == 6 || countSumo == 9 || countSumo == 12 || countSumo == 15 || countSumo == 18 || countSumo == 21)
            {
                edgeAntColony("5", "15", "100", "15");
            }
        }



        /// When Speed = textbox10.Text, That Antcolony For Edge2, Edge5, Edge8, Edge 11
        public void combinedEdgeAntColony(string edgeNumber)
        {
            if(edgeNumber == "edge2")
            {
                row1_edge2 = textBox10.Text; row1_edge5 = "50" ;  row1_edge8 = "40" ; row1_edge11 = "50" ;
                row2_edge2 = textBox10.Text; row2_edge5 = "100";  row2_edge8 = "80" ; row2_edge11 = "100";
                row3_edge2 = textBox10.Text; row3_edge5 = "15" ;  row3_edge8 = "100"; row3_edge11 = "15" ;
                combinedEdgeAntColonyRowValue();
            }
            if(edgeNumber == "edge5")
            {
                row1_edge2 = "120" ; row1_edge5 = textBox10.Text; row1_edge8 = "40" ; row1_edge11 = "50" ;
                row2_edge2 = "50"  ; row2_edge5 = textBox10.Text; row2_edge8 = "80" ; row2_edge11 = "100";
                row3_edge2 = "5"   ; row3_edge5 = textBox10.Text; row3_edge8 = "100"; row3_edge11 = "15" ;
                combinedEdgeAntColonyRowValue();
            }
            if (edgeNumber == "edge8")
            {
                row1_edge2 = "120" ; row1_edge5 = "50" ; row1_edge8 = textBox10.Text; row1_edge11 = "50" ;
                row2_edge2 = "50"  ; row2_edge5 = "100"; row2_edge8 = textBox10.Text; row2_edge11 = "100";
                row3_edge2 = "5"   ; row3_edge5 = "15" ; row3_edge8 = textBox10.Text; row3_edge11 = "15" ;
                combinedEdgeAntColonyRowValue();
            }
            if (edgeNumber == "edge11")
            {
                row1_edge2 = "120" ; row1_edge5 = "50" ; row1_edge8 = "40" ; row1_edge11 = textBox10.Text;
                row2_edge2 = "50"  ; row2_edge5 = "100"; row2_edge8 = "80" ; row2_edge11 = textBox10.Text;
                row3_edge2 = "5"   ; row3_edge5 = "15" ; row3_edge8 = "100"; row3_edge11 = textBox10.Text;
                combinedEdgeAntColonyRowValue();
            }
        }



        /// Antcolony Edge2 Edge5
        public void combinedEdgeAntColony_Edge2_Edge5(string edgeNumber1, string edgeNumber2)
        {
            if (edgeNumber1 == "edge2" || edgeNumber2 == "edge5")
            {
                row1_edge2 = textBox10.Text; row1_edge5 = textBox10.Text; row1_edge8 = "40" ; row1_edge11 = "50" ;
                row2_edge2 = textBox10.Text; row2_edge5 = textBox10.Text; row2_edge8 = "80" ; row2_edge11 = "100";
                row3_edge2 = textBox10.Text; row3_edge5 = textBox10.Text; row3_edge8 = "100"; row3_edge11 = "15" ;
                combinedEdgeAntColonyRowValue();
            }
        }

        /// Antcolony Edge2 Edge8
        public void combinedEdgeAntColony_Edge2_Edge8(string edgeNumber1, string edgeNumber2)
        {
            if (edgeNumber1 == "edge2" || edgeNumber2 == "edge8")
            {
                row1_edge2 = textBox10.Text; row1_edge5 = "50" ; row1_edge8 = textBox10.Text; row1_edge11 = "50" ;
                row2_edge2 = textBox10.Text; row2_edge5 = "100"; row2_edge8 = textBox10.Text; row2_edge11 = "100";
                row3_edge2 = textBox10.Text; row3_edge5 = "15" ; row3_edge8 = textBox10.Text; row3_edge11 = "15" ;
                combinedEdgeAntColonyRowValue();
            }
        }

        ///*** Antcolony Edge2 Edge11
        public void combinedEdgeAntColony_Edge2_Edge11(string edgeNumber1, string edgeNumber2)
        {
            if (edgeNumber1 == "edge2" || edgeNumber2 == "edge11")
            {
                row1_edge2 = textBox10.Text; row1_edge5 = "50" ; row1_edge8 = "40" ; row1_edge11 = textBox10.Text;
                row2_edge2 = textBox10.Text; row2_edge5 = "100"; row2_edge8 = "80" ; row2_edge11 = textBox10.Text;
                row3_edge2 = textBox10.Text; row3_edge5 = "15" ; row3_edge8 = "100"; row3_edge11 = textBox10.Text;
                combinedEdgeAntColonyRowValue();
            }
        }

        /// Antcolony Edge5 Edge8
        public void combinedEdgeAntColony_Edge5_Edge8(string edgeNumber1, string edgeNumber2)
        {
            if (edgeNumber1 == "edge5" || edgeNumber2 == "edge8")
            {
                row1_edge2 = "120"; row1_edge5 = textBox10.Text; row1_edge8 = textBox10.Text; row1_edge11 = "50" ;
                row2_edge2 = "50" ; row2_edge5 = textBox10.Text; row2_edge8 = textBox10.Text; row2_edge11 = "100";
                row3_edge2 = "5"  ; row3_edge5 = textBox10.Text; row3_edge8 = textBox10.Text; row3_edge11 = "15" ;
                combinedEdgeAntColonyRowValue();
            }
        }

        /// Antcolony Edge5 Edge11
        public void combinedEdgeAntColony_Edge5_Edge11(string edgeNumber1, string edgeNumber2)
        {
            if (edgeNumber1 == "edge5" || edgeNumber2 == "edge11")
            {
                row1_edge2 = "120"; row1_edge5 = textBox10.Text; row1_edge8 = "40" ; row1_edge11 = textBox10.Text;
                row2_edge2 = "50" ; row2_edge5 = textBox10.Text; row2_edge8 = "80" ; row2_edge11 = textBox10.Text;
                row3_edge2 = "5"  ; row3_edge5 = textBox10.Text; row3_edge8 = "100"; row3_edge11 = textBox10.Text;
                combinedEdgeAntColonyRowValue();
            }
        }

        /// Antcolony Edge8 Edge11
        public void combinedEdgeAntColony_Edge8_Edge11(string edgeNumber1, string edgeNumber2)
        {
            if (edgeNumber1 == "edge8" || edgeNumber2 == "edge11")
            {
                row1_edge2 = "120"; row1_edge5 = "50" ; row1_edge8 = textBox10.Text; row1_edge11 = textBox10.Text;
                row2_edge2 = "50" ; row2_edge5 = "100"; row2_edge8 = textBox10.Text; row2_edge11 = textBox10.Text;
                row3_edge2 = "5"  ; row3_edge5 = "15" ; row3_edge8 = textBox10.Text; row3_edge11 = textBox10.Text;
                combinedEdgeAntColonyRowValue();
            }
        }

        /// Antcolony Edge2 Edge5 Edge8
        public void combinedEdgeAntColony_Edge2_Edge5_Edge8(string edgeNumber1, string edgeNumber2, string edgeNumber3)
        {
            if (edgeNumber1 == "edge2" || edgeNumber2 == "edge5" || edgeNumber2 == "edge8")
            {
                row1_edge2 = textBox10.Text; row1_edge5 = textBox10.Text; row1_edge8 = textBox10.Text; row1_edge11 = "50" ;
                row2_edge2 = textBox10.Text; row2_edge5 = textBox10.Text; row2_edge8 = textBox10.Text; row2_edge11 = "100";
                row3_edge2 = textBox10.Text; row3_edge5 = textBox10.Text; row3_edge8 = textBox10.Text; row3_edge11 = "15" ;
                combinedEdgeAntColonyRowValue();
            }
        }

        /// Antcolony Edge2 Edge5 Edge11
        public void combinedEdgeAntColony_Edge2_Edge5_Edge11(string edgeNumber1, string edgeNumber2, string edgeNumber3)
        {
            if (edgeNumber1 == "edge2" || edgeNumber2 == "edge5" || edgeNumber2 == "edge11")
            {
                row1_edge2 = textBox10.Text; row1_edge5 = textBox10.Text; row1_edge8 = "40" ; row1_edge11 = textBox10.Text;
                row2_edge2 = textBox10.Text; row2_edge5 = textBox10.Text; row2_edge8 = "80" ; row2_edge11 = textBox10.Text;
                row3_edge2 = textBox10.Text; row3_edge5 = textBox10.Text; row3_edge8 = "100"; row3_edge11 = textBox10.Text;
                combinedEdgeAntColonyRowValue();
            }
        }

        /// Antcolony Edge2 Edge8 Edge11
        public void combinedEdgeAntColony_Edge2_Edge8_Edge11(string edgeNumber1, string edgeNumber2, string edgeNumber3)
        {
            if (edgeNumber1 == "edge2" || edgeNumber2 == "edge8" || edgeNumber2 == "edge11")
            {
                row1_edge2 = textBox10.Text; row1_edge5 = "50" ; row1_edge8 = textBox10.Text; row1_edge11 = textBox10.Text;
                row2_edge2 = textBox10.Text; row2_edge5 = "100"; row2_edge8 = textBox10.Text; row2_edge11 = textBox10.Text;
                row3_edge2 = textBox10.Text; row3_edge5 = "15" ; row3_edge8 = textBox10.Text; row3_edge11 = textBox10.Text;
                combinedEdgeAntColonyRowValue();
            }
        }

        /// Antcolony Edge5 Edge8 Edge11
        public void combinedEdgeAntColony_Edge5_Edge8_Edge11(string edgeNumber1, string edgeNumber2, string edgeNumber3)
        {
            if (edgeNumber1 == "edge5" || edgeNumber2 == "edge8" || edgeNumber2 == "edge11")
            {
                row1_edge2 = "120"; row1_edge5 = textBox10.Text; row1_edge8 = textBox10.Text; row1_edge11 = textBox10.Text;
                row2_edge2 = "50" ; row2_edge5 = textBox10.Text; row2_edge8 = textBox10.Text; row2_edge11 = textBox10.Text;
                row3_edge2 = "5"  ; row3_edge5 = textBox10.Text; row3_edge8 = textBox10.Text; row3_edge11 = textBox10.Text;
                combinedEdgeAntColonyRowValue();
            }
        }

        /// Antcolony Edge2 Edge5 Edge8 Edge11
        public void combinedEdgeAntColony_Edge2_Edge5_Edge8_Edge11(string edgeNumber1, string edgeNumber2, string edgeNumber3, string edgeNumber4)
        {
            if (edgeNumber1 == "edge2" || edgeNumber2 == "edge5" || edgeNumber1 == "edge8" || edgeNumber2 == "edge11")
            {
                row1_edge2 = textBox10.Text; row1_edge5 = textBox10.Text; row1_edge8 = textBox10.Text; row1_edge11 = textBox10.Text;
                row2_edge2 = textBox10.Text; row2_edge5 = textBox10.Text; row2_edge8 = textBox10.Text; row2_edge11 = textBox10.Text;
                row3_edge2 = textBox10.Text; row3_edge5 = textBox10.Text; row3_edge8 = textBox10.Text; row3_edge11 = textBox10.Text;
                combinedEdgeAntColonyRowValue();
            }
        }


        /// Row And Edge Value For Antcolony Given From Input And Default
        public void combinedEdgeAntColonyRowValue()
        {
            if (countSumo == 1 || countSumo == 4 || countSumo == 7 || countSumo == 10 || countSumo == 13 || countSumo == 16 || countSumo == 19)
            {
                edgeAntColony(row1_edge2, row1_edge5, row1_edge8, row1_edge11);
            }

            if (countSumo == 2 || countSumo == 5 || countSumo == 8 || countSumo == 11 || countSumo == 14 || countSumo == 17 || countSumo == 20)
            {
                edgeAntColony(row2_edge2, row2_edge5, row2_edge8, row2_edge11);
            }

            if (countSumo == 3 || countSumo == 6 || countSumo == 9 || countSumo == 12 || countSumo == 15 || countSumo == 18 || countSumo == 21)
            {
                edgeAntColony(row3_edge2, row3_edge5, row3_edge8, row3_edge11);
            }
        }

        public void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            var item = checkedListBox1.CheckedIndices;
            /// Road Status For Edge2
            if (checkBox1.CheckState == CheckState.Checked && checkBox2.CheckState == CheckState.Checked && item.Count == 1 && checkedListBox1.Text == "edge2")
            {
                Edge2_RoadStatus edge2_roadState = new Edge2_RoadStatus();
                edge2_roadState.ShowDialog();

                foreach (int checkedItemindex in checkedListBox1.CheckedIndices)
                {
                    if (checkedItemindex == 0)
                    {
                        checkedListBox1.SetItemChecked(checkedItemindex, false);
                    }
                }
            }
            /// Road Status For Edge5
            else if (checkBox1.CheckState == CheckState.Checked && checkBox2.CheckState == CheckState.Checked && item.Count == 1 && checkedListBox1.Text == "edge5")
            {
                Edge5_RoadStatus edge5_roadState = new Edge5_RoadStatus();
                edge5_roadState.ShowDialog();

                foreach (int checkedItemindex in checkedListBox1.CheckedIndices)
                {
                    if (checkedItemindex == 1)
                    {
                        checkedListBox1.SetItemChecked(checkedItemindex, false);
                    }
                }
            }
            /// Road Status For Edge6
            else if (checkBox1.CheckState == CheckState.Checked && checkBox2.CheckState == CheckState.Checked && item.Count == 1 && checkedListBox1.Text == "edge6")
            {
                Edge6_RoadStatus edge6_roadState = new Edge6_RoadStatus();
                edge6_roadState.ShowDialog();

                foreach (int checkedItemindex in checkedListBox1.CheckedIndices)
                {
                    if (checkedItemindex == 2)
                    {
                        checkedListBox1.SetItemChecked(checkedItemindex, false);
                    }
                }
            }
            /// Road Status For Edge8
            else if (checkBox1.CheckState == CheckState.Checked && checkBox2.CheckState == CheckState.Checked && item.Count == 1 && checkedListBox1.Text == "edge8")
            {
                
                Edge8_RoadStatus edge8_roadState = new Edge8_RoadStatus();
                edge8_roadState.ShowDialog();

                foreach (int checkedItemindex in checkedListBox1.CheckedIndices)
                {
                    if (checkedItemindex == 3)
                    {
                        checkedListBox1.SetItemChecked(checkedItemindex, false);
                    }
                }
            }
            /// Road Status For Edge11
            else if (checkBox1.CheckState == CheckState.Checked && checkBox2.CheckState == CheckState.Checked && item.Count == 1 && checkedListBox1.Text == "edge11")
            {
                Edge11_RoadStatus edge11_roadState = new Edge11_RoadStatus();
                edge11_roadState.ShowDialog();

                foreach (int checkedItemindex in checkedListBox1.CheckedIndices)
                {
                    if (checkedItemindex == 4)
                    {
                        checkedListBox1.SetItemChecked(checkedItemindex, false);
                    }
                }
            }
            else
            {
                MessageBox.Show("Error...");

                checkBox1.CheckState = CheckState.Unchecked;
                checkBox2.CheckState = CheckState.Unchecked;
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            var item = checkedListBox1.CheckedIndices;
            /// Road Construction For Edge2
            if (checkBox1.CheckState == CheckState.Checked && checkBox3.CheckState == CheckState.Checked && item.Count == 1 && checkedListBox1.Text == "edge2")
            {
                Edge2_RoadConstruction edge2_roadConstruction = new Edge2_RoadConstruction();
                edge2_roadConstruction.ShowDialog();

                foreach (int checkedItemindex in checkedListBox1.CheckedIndices)
                {
                    if (checkedItemindex == 0)
                    {
                        checkedListBox1.SetItemChecked(checkedItemindex, false);
                    }
                }
            }
            /// Road Construction For Edge5
            else if (checkBox1.CheckState == CheckState.Checked && checkBox3.CheckState == CheckState.Checked && item.Count == 1 && checkedListBox1.Text == "edge5")
            {
                Edge5_RoadConstruction edge5_roadConstruction = new Edge5_RoadConstruction();
                edge5_roadConstruction.ShowDialog();

                foreach (int checkedItemindex in checkedListBox1.CheckedIndices)
                {
                    if (checkedItemindex == 1)
                    {
                        checkedListBox1.SetItemChecked(checkedItemindex, false);
                    }
                }
            }
            /// Road Construction For Edge6
            else if (checkBox1.CheckState == CheckState.Checked && checkBox3.CheckState == CheckState.Checked && item.Count == 1 && checkedListBox1.Text == "edge6")
            {
                Edge6_RoadConstruction edge6_roadConstruction = new Edge6_RoadConstruction();
                edge6_roadConstruction.ShowDialog();

                foreach (int checkedItemindex in checkedListBox1.CheckedIndices)
                {
                    if (checkedItemindex == 2)
                    {
                        checkedListBox1.SetItemChecked(checkedItemindex, false);
                    }
                }
            }
            /// Road Construction For Edge8
            else if (checkBox1.CheckState == CheckState.Checked && checkBox3.CheckState == CheckState.Checked && item.Count == 1 && checkedListBox1.Text == "edge8")
            {
                Edge8_RoadConstruction edge8_roadConstruction = new Edge8_RoadConstruction();
                edge8_roadConstruction.ShowDialog();

                foreach (int checkedItemindex in checkedListBox1.CheckedIndices)
                {
                    if (checkedItemindex == 3)
                    {
                        checkedListBox1.SetItemChecked(checkedItemindex, false);
                    }
                }
            }
            /// Road Construction For Edge11
            else if (checkBox1.CheckState == CheckState.Checked && checkBox3.CheckState == CheckState.Checked && item.Count == 1 && checkedListBox1.Text == "edge11")
            {
                Edge11_RoadConstruction edge11_roadConstruction = new Edge11_RoadConstruction();
                edge11_roadConstruction.ShowDialog();

                foreach (int checkedItemindex in checkedListBox1.CheckedIndices)
                {
                    if (checkedItemindex == 4)
                    {
                        checkedListBox1.SetItemChecked(checkedItemindex, false);
                    }
                }
            }
            else
            {
                MessageBox.Show("Error...");

                checkBox1.CheckState = CheckState.Unchecked;
                checkBox3.CheckState = CheckState.Unchecked;
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            var item = checkedListBox1.CheckedIndices;
            /// Road Accident For Edge2
            if (checkBox1.CheckState == CheckState.Checked && checkBox4.CheckState == CheckState.Checked && item.Count == 1 && checkedListBox1.Text == "edge2")
            {
                Edge2_RoadAccident edge2_roadAccident = new Edge2_RoadAccident();
                edge2_roadAccident.ShowDialog();

                foreach (int checkedItemindex in checkedListBox1.CheckedIndices)
                {
                    if (checkedItemindex == 0)
                    {
                        checkedListBox1.SetItemChecked(checkedItemindex, false);
                    }
                }
            }
            /// Road Accident For Edge5
            else if (checkBox1.CheckState == CheckState.Checked && checkBox4.CheckState == CheckState.Checked && item.Count == 1 && checkedListBox1.Text == "edge5")
            {
                Edge5_RoadAccident edge5_roadAccident = new Edge5_RoadAccident();
                edge5_roadAccident.ShowDialog();

                foreach (int checkedItemindex in checkedListBox1.CheckedIndices)
                {
                    if (checkedItemindex == 1)
                    {
                        checkedListBox1.SetItemChecked(checkedItemindex, false);
                    }
                }
            }
            /// Road Accident For Edge6
            else if (checkBox1.CheckState == CheckState.Checked && checkBox4.CheckState == CheckState.Checked && item.Count == 1 && checkedListBox1.Text == "edge6")
            {
                Edge6_RoadAccident edge6_roadAccident = new Edge6_RoadAccident();
                edge6_roadAccident.ShowDialog();

                foreach (int checkedItemindex in checkedListBox1.CheckedIndices)
                {
                    if (checkedItemindex == 2)
                    {
                        checkedListBox1.SetItemChecked(checkedItemindex, false);
                    }
                }
            }
            /// Road Accident For Edge8
            else if (checkBox1.CheckState == CheckState.Checked && checkBox4.CheckState == CheckState.Checked && item.Count == 1 && checkedListBox1.Text == "edge8")
            {
                Edge8_RoadAccident edge8_roadAccident = new Edge8_RoadAccident();
                edge8_roadAccident.ShowDialog();

                foreach (int checkedItemindex in checkedListBox1.CheckedIndices)
                {
                    if (checkedItemindex == 3)
                    {
                        checkedListBox1.SetItemChecked(checkedItemindex, false);
                    }
                }
            }
            /// Road Accident For Edge11
            else if (checkBox1.CheckState == CheckState.Checked && checkBox4.CheckState == CheckState.Checked && item.Count == 1 && checkedListBox1.Text == "edge11")
            {
                Edge11_RoadAccident edge11_roadAccident = new Edge11_RoadAccident();
                edge11_roadAccident.ShowDialog();

                foreach (int checkedItemindex in checkedListBox1.CheckedIndices)
                {
                    if (checkedItemindex == 4)
                    {
                        checkedListBox1.SetItemChecked(checkedItemindex, false);
                    }
                }
            }
            else
            {
                MessageBox.Show("Error...");

                checkBox1.CheckState = CheckState.Unchecked;
                checkBox4.CheckState = CheckState.Unchecked;
            }        
        }

        private void button3_Click(object sender, EventArgs e)
        {
            sumoGuiFunction();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            processTimer.Start();
            sumoGuiFunction();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            foreach (var process_2 in Process.GetProcessesByName(label14.Text))
            {
                process_2.Kill();
                processTimer.Enabled = false;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            SimulationSettings simulationSettings = new SimulationSettings();
            simulationSettings.ShowDialog();
        }

        public void latestFileAdding()
        {
            /// Latest File Adding
            string Folder = @"H:\Thesis\Sumo\Examples\Additional\Test7";
            var files = new DirectoryInfo(Folder).GetFiles("test7_*.xml");
            string latestfile = "";

            DateTime lastupdated = DateTime.MinValue;

            foreach (FileInfo file in files)
            {
                if (file.LastWriteTime > lastupdated)
                {
                    lastupdated = file.LastWriteTime;
                    latestfile = file.Name;
                }
            }

            /// Latest File Load, Push, Save
            XElement xelement = XElement.Load(@"H:\Thesis\Sumo\Examples\Additional\Test7\test7.sumocfg");

            IEnumerable<XElement> configuration = xelement.Elements();

            List<string> menuList = new List<string>();
            List<string> subMenuList = new List<string>();

            int i = 0;

            foreach (var menu in configuration)
            {
                foreach (var submenu in menu.Elements())
                {
                    if (i == 2)
                    {
                        subMenuList.Add(submenu.Attribute("value").Value = latestfile);
                        break;
                    }
                    i++;
                }
                break;
            }
            xelement.Save(@"H:\Thesis\Sumo\Examples\Additional\Test7\test7.sumocfg");
        }

        public void sumoGuiFunction()
        {
            process_timer = new Process();
            process_timer.StartInfo.FileName = "cmd.exe";
            process_timer.StartInfo.CreateNoWindow = true;
            process_timer.StartInfo.RedirectStandardInput = true;
            process_timer.StartInfo.RedirectStandardOutput = true;
            process_timer.StartInfo.UseShellExecute = false;
            process_timer.Start();
            process_timer.StandardInput.WriteLine("h:");
            process_timer.StandardInput.WriteLine(@"cd H:\Thesis\Sumo\Examples\Additional\Test7");
            process_timer.StandardInput.WriteLine("sumo-gui --routing-algorithm astar --start -c test7.sumocfg");
            process_timer.StandardInput.Flush();
            process_timer.StandardInput.Close();
            process_timer.WaitForExit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            countChange = 0;
            if (checkBox1.CheckState != CheckState.Checked && (checkedListBox1.Text == "edge2" || checkedListBox1.Text == "edge5" || checkedListBox1.Text == "edge6" ||
                                                               checkedListBox1.Text == "edge8" || checkedListBox1.Text == "edge11"))
            {
                /// Latest File Adding
                latestFileAdding();

                /// Checking Null In TextBox1 - TextBox5
                if ((string.IsNullOrEmpty(textBox1.Text)))
                {
                    textBox1.Text = "80";
                }
                if ((string.IsNullOrEmpty(textBox2.Text)))
                {
                    textBox2.Text = "30";
                }
                if ((string.IsNullOrEmpty(textBox3.Text)))
                {
                    textBox3.Text = "0";
                }
                if ((string.IsNullOrEmpty(textBox4.Text)))
                {
                    textBox4.Text = "25";
                }
                if ((string.IsNullOrEmpty(textBox5.Text)))
                {
                    textBox5.Text = "1";
                }

                /// Checking In Valid Value
                int flag = 0;
                if(Double.Parse(textBox1.Text, CultureInfo.InvariantCulture) > 95 || Double.Parse(textBox1.Text, CultureInfo.InvariantCulture) < 32)
                {
                    MessageBox.Show("Humidity Value Must Be 32-95");
                    flag = 1;
                }
                if (Double.Parse(textBox2.Text, CultureInfo.InvariantCulture) > 129 || Double.Parse(textBox2.Text, CultureInfo.InvariantCulture) < 8)
                {
                    MessageBox.Show("Peak Hour Value Must Be 8-129");
                    flag = 2;
                }
                if (Double.Parse(textBox3.Text, CultureInfo.InvariantCulture) > 30 || Double.Parse(textBox3.Text, CultureInfo.InvariantCulture) < 0)
                {
                    MessageBox.Show("Rainfall Value Must Be 0-30");
                    flag = 3;
                }
                if (Double.Parse(textBox4.Text, CultureInfo.InvariantCulture) > 34 || Double.Parse(textBox4.Text, CultureInfo.InvariantCulture) < 13)
                {
                    MessageBox.Show("Temperature Value Must Be 13-34");
                    flag = 4;
                }
                if (Double.Parse(textBox5.Text, CultureInfo.InvariantCulture) > 15 || Double.Parse(textBox5.Text, CultureInfo.InvariantCulture) < 0)
                {
                    MessageBox.Show("Wind Speed Value Must Be 0-15");
                    flag = 5;
                }


                if (flag == 0)
                {
                    /// Input Textbox Value and Creating out.txt
                    Process process = new Process();
                    process.StartInfo.FileName = "cmd.exe";
                    process.StartInfo.CreateNoWindow = true;
                    process.StartInfo.RedirectStandardInput = true;
                    process.StartInfo.RedirectStandardOutput = true;
                    process.StartInfo.UseShellExecute = false;
                    process.Start();
                    process.StandardInput.WriteLine("h:");
                    process.StandardInput.WriteLine(@"cd H:\Thesis\NeuroFuzzy");
                    process.StandardInput.WriteLine("python infer.py --humidity " + textBox1.Text + " --peekhour " + textBox2.Text + " --rainfall " + textBox3.Text + " --temperature " + textBox4.Text + " --wind " + textBox5.Text + " --road_status 0 --road_construction 0 --road_accident 0 --vehicle_speed 30");
                    process.StandardInput.Flush();
                    process.StandardInput.Close();
                    process.WaitForExit();


                    /// Show out.Txt Value
                    string weight;
                    string speed;
                    string line;
                    string file2 = "H:/Thesis/NeuroFuzzy/out.txt";
                    StreamReader myFile = new StreamReader(file2);
                    while (myFile.EndOfStream == false)
                    {
                        line = myFile.ReadLine();
                        weight = line;

                        if (weight == "0")
                        {
                            speed = "40";
                        }
                        else if (weight == "1")
                        {
                            speed = "37";
                            textBox10.Text = speed;
                        }
                        else if (weight == "2")
                        {
                            speed = "33";
                            textBox10.Text = speed;
                        }
                        else if (weight == "3")
                        {
                            speed = "30";
                            textBox10.Text = speed;
                        }
                        else if (weight == "4")
                        {
                            speed = "25";
                            textBox10.Text = speed;
                        }
                        else if (weight == "5")
                        {
                            speed = "21";
                            textBox10.Text = speed;
                        }
                        else if (weight == "6")
                        {
                            speed = "18";
                            textBox10.Text = speed;
                        }
                        else if (weight == "7")
                        {
                            speed = "15";
                            textBox10.Text = speed;
                        }
                        else if (weight == "8")
                        {
                            speed = "12";
                            textBox10.Text = speed;
                        }
                        else if (weight == "9")
                        {
                            speed = "8";
                            textBox10.Text = speed;
                        }
                        else if (weight == "10")
                        {
                            speed = "5";
                            textBox10.Text = speed;
                        }
                    }
                    myFile.Close();

                    /// Weight Setting On Edge And Lane
                    XElement xelement_2 = XElement.Load(@"H:\Thesis\Sumo\Examples\Additional\Test7\test7.net.xml");

                    IEnumerable<XElement> net = xelement_2.Elements();

                    List<string> menuList_2 = new List<string>();
                    List<string> subMenuList_2 = new List<string>();

                    foreach (var menu in net)
                    {
                        try
                        {
                            foreach (string edge in checkedListBox1.CheckedItems)
                            {                                
                                if(edge == "edge2")
                                {
                                    if (menu.Attribute("id").Value == "edge2a" || menu.Attribute("id").Value == "edge2b")
                                    {
                                        foreach (var submenu in menu.Elements())
                                        {
                                            subMenuList_2.Add(submenu.Attribute("speed").Value = textBox10.Text);
                                        }
                                    }
                                }
                                
                                if (edge == "edge5")
                                {
                                    if (menu.Attribute("id").Value == "edge5a" || menu.Attribute("id").Value == "edge5b")
                                    {
                                        foreach (var submenu in menu.Elements())
                                        {
                                            subMenuList_2.Add(submenu.Attribute("speed").Value = textBox10.Text);
                                        }
                                    }
                                }

                                if (edge == "edge6")
                                {
                                    if (menu.Attribute("id").Value == "edge6a" || menu.Attribute("id").Value == "edge6b")
                                    {
                                        foreach (var submenu in menu.Elements())
                                        {
                                            subMenuList_2.Add(submenu.Attribute("speed").Value = textBox10.Text);
                                        }
                                    }
                                }

                                if (edge == "edge8")
                                {
                                    if (menu.Attribute("id").Value == "edge8a" || menu.Attribute("id").Value == "edge8b")
                                    {
                                        foreach (var submenu in menu.Elements())
                                        {
                                            subMenuList_2.Add(submenu.Attribute("speed").Value = textBox10.Text);
                                        }
                                    }
                                }

                                if (edge == "edge11")
                                {
                                    if (menu.Attribute("id").Value == "edge11a" || menu.Attribute("id").Value == "edge11b")
                                    {
                                        foreach (var submenu in menu.Elements())
                                        {
                                            subMenuList_2.Add(submenu.Attribute("speed").Value = textBox10.Text);
                                        }
                                    }
                                }
                            }
                        }

                        catch (Exception)
                        { }

                        xelement_2.Save(@"H:\Thesis\Sumo\Examples\Additional\Test7\test7.net.xml");
                    }

                    countChange++;

                    Main_Form main_form = new Main_Form();
                    ///this.Hide();

                    ///Sumo-Gui Automatic Closing And Starting Load File
                    foreach (var process_2 in Process.GetProcessesByName(label14.Text))
                    {
                        process_2.Kill();
                    }
                    sumoGuiFunction();
                }
            }
        }

        private void checkBox1_CheckedChanged_1(object sender, EventArgs e)
        {
            if (checkBox1.CheckState == CheckState.Checked && checkBox4.CheckState == CheckState.Checked)
            {
                MessageBox.Show("Error...");

                checkBox1.CheckState = CheckState.Unchecked;
                checkBox4.CheckState = CheckState.Unchecked;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (processTimer.Enabled)
            {
                processTimer.Enabled = false;
                button8.Text = "Simulation Play";
                foreach (var process_close in Process.GetProcessesByName("sumo-gui"))
                {
                    process_close.Kill();
                    processTimer.Enabled = false;
                }
            }
            else
            {
                processTimer.Enabled = true;
                button8.Text = "Simulation Pause";
            }
        }

        ///Applying Ant Colony In Edge2, Edge5, Edge8, Edge11
        public void edgeAntColony(string edge2_speed, string edge5_speed, string edge8_speed, string edge11_speed)
        {
            /// Weight Setting On Edge And Lane
            XElement xelement_ant = XElement.Load(@"H:\Thesis\Sumo\Examples\Additional\Test7\test7.net.xml");

            IEnumerable<XElement> net = xelement_ant.Elements();

            List<string> menuList_ant = new List<string>();
            List<string> subMenuList_ant = new List<string>();

            foreach (var menu in net)
            {
                try
                {
                    if (menu.Attribute("id").Value == "edge2a" || menu.Attribute("id").Value == "edge2b")
                    {
                        foreach (var submenu in menu.Elements())
                        {
                            subMenuList_ant.Add(submenu.Attribute("speed").Value = edge2_speed);
                        }
                    }

                    if (menu.Attribute("id").Value == "edge5a" || menu.Attribute("id").Value == "edge5b")
                    {
                        foreach (var submenu in menu.Elements())
                        {
                            subMenuList_ant.Add(submenu.Attribute("speed").Value = edge5_speed);
                        }
                    }

                    if (menu.Attribute("id").Value == "edge8a" || menu.Attribute("id").Value == "edge8b")
                    {
                        foreach (var submenu in menu.Elements())
                        {
                            subMenuList_ant.Add(submenu.Attribute("speed").Value = edge8_speed);
                        }
                    }

                    if (menu.Attribute("id").Value == "edge11a" || menu.Attribute("id").Value == "edge11b")
                    {
                        foreach (var submenu in menu.Elements())
                        {
                            subMenuList_ant.Add(submenu.Attribute("speed").Value = edge11_speed);
                        }
                    }
                }

                catch (Exception)
                { }

                xelement_ant.Save(@"H:\Thesis\Sumo\Examples\Additional\Test7\test7.net.xml");
            }
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void textBox6_TextChanged_1(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            /// Back Track
            XElement xelement_bt = XElement.Load(@"H:\Thesis\Sumo\Examples\Additional\Test7\test7.sumocfg");

            IEnumerable<XElement> configuration = xelement_bt.Elements();

            List<string> menuList = new List<string>();
            List<string> subMenuList = new List<string>();

            int i = 0;

            foreach (var menu in configuration)
            {
                foreach (var submenu in menu.Elements())
                {
                    if (i == 2)
                    {
                        ///test7_50.00.xml
                        subMenuList.Add(submenu.Attribute("value").Value = "test7_" + textBox6.Text + ".00.xml");
                        break;
                    }
                    i++;
                }
                break;
            }
            xelement_bt.Save(@"H:\Thesis\Sumo\Examples\Additional\Test7\test7.sumocfg");

            sumoGuiFunction();

            Thread.Sleep(5000);
            /// Delete Old State Files
            Process process = new Process();
            process.StartInfo.FileName = "cmd.exe";
            process.StartInfo.CreateNoWindow = true;
            process.StartInfo.RedirectStandardInput = true;
            process.StartInfo.RedirectStandardOutput = true;
            process.StartInfo.UseShellExecute = false;
            process.Start();
            process.StandardInput.WriteLine("h:");
            process.StandardInput.WriteLine(@"cd H:\Thesis\Sumo\Examples\Additional\Test7");
            process.StandardInput.WriteLine("Delete.bat");
            ///process.StandardInput.WriteLine("Delete2.bat");
            ///process.StandardInput.WriteLine("Delete3.bat");
            process.StandardInput.Flush();
            process.StandardInput.Close();
            process.WaitForExit();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Sumo_Antcolony sumo_antcolony = new Sumo_Antcolony();
            sumo_antcolony.Show();
            this.Hide();
        }
    }
}