﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sumo_Test_GUI5
{
    public partial class Sumo_Antcolony : Form
    {
        public Sumo_Antcolony()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Sumo_Basic_Algorithms_Apply sumo_basic_algorithms_apply = new Sumo_Basic_Algorithms_Apply();
            sumo_basic_algorithms_apply.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Sample_Map_Antcolony sample_map_antcolony = new Sample_Map_Antcolony();
            sample_map_antcolony.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Real_Map real_map = new Real_Map();
            real_map.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Main_Form main_form = new Main_Form();
            main_form.Show();
            this.Hide();
        }
    }
}
