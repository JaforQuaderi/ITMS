﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sumo_Test_GUI5
{
    public partial class Real_Map_Default_Normal : Form
    {
        public Real_Map_Default_Normal()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Process process;

            process = new Process();
            process.StartInfo.FileName = "cmd.exe";
            process.StartInfo.CreateNoWindow = true;
            process.StartInfo.RedirectStandardInput = true;
            process.StartInfo.RedirectStandardOutput = true;
            process.StartInfo.UseShellExecute = false;
            process.Start();
            process.StandardInput.WriteLine("h:");
            process.StandardInput.WriteLine(@"cd H:\Thesis\VS17\Sumo_XML\Thesis\Dhaka Map_Test7 Default Normal");
            process.StandardInput.WriteLine("sumo-gui --routing-algorithm astar --start -c test7.sumocfg");
            process.StandardInput.Flush();
            process.StandardInput.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            foreach (var process_2 in Process.GetProcessesByName("sumo-gui"))
            {
                process_2.Kill();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Real_Map_Deafult_Simulation real_rmap_deafult_simulation = new Real_Map_Deafult_Simulation();
            real_rmap_deafult_simulation.Show();
            this.Hide();
        }

        private void Real_Map_Default_Normal_Load(object sender, EventArgs e)
        {

        }
    }
}
