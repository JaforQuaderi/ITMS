﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Sumo_Test_GUI5
{
    public partial class Sample_Map_Antcolony_Normal : Form
    {
        private System.Windows.Forms.Timer processTimer;
        Process process;
        int countSumo = 0;

        public string row1_edge2;
        public string row2_edge2;
        public string row3_edge2;
        public string row1_edge5;
        public string row2_edge5;
        public string row3_edge5;
        public string row1_edge8;
        public string row2_edge8;
        public string row3_edge8;
        public string row1_edge11;
        public string row2_edge11;
        public string row3_edge11;

        public Sample_Map_Antcolony_Normal()
        {
            InitializeComponent();
        }

        private void Sample_Map_Antcolony_Normal_Load(object sender, EventArgs e)
        {
            processTimer = new System.Windows.Forms.Timer();
            processTimer.Tick += new EventHandler(processTimer_Tick);
            processTimer.Interval = 20 * 1000;
        }

        private void processTimer_Tick(object sender, EventArgs e)
        {
            if (process != null)
            {
                foreach (var process2 in Process.GetProcessesByName("sumo-gui"))
                {
                    process2.Kill();
                }
                process = null;

                latestFileAdding();
            }
            countSumo++;
            baseAntcolony();
            sumoGuiFunction();
        }

        public void baseAntcolony()
        {
            if (countSumo == 1 || countSumo == 4 || countSumo == 7 || countSumo == 10 || countSumo == 13 || countSumo == 16 || countSumo == 19)
            {
                edgeAntColony("120", "50", "40", "50");
            }

            if (countSumo == 2 || countSumo == 5 || countSumo == 8 || countSumo == 11 || countSumo == 14 || countSumo == 17 || countSumo == 20)
            {
                edgeAntColony("50", "100", "80", "100");
            }

            if (countSumo == 3 || countSumo == 6 || countSumo == 9 || countSumo == 12 || countSumo == 15 || countSumo == 18 || countSumo == 21)
            {
                edgeAntColony("5", "15", "100", "15");
            }
        }

        public void edgeAntColony(string edge2_speed, string edge5_speed, string edge8_speed, string edge11_speed)
        {
            /// Weight Setting On Edge And Lane
            XElement xelement_ant = XElement.Load(@"H:\Thesis\VS17\Sumo_XML\Thesis\Sample Map Antcolony Normal\test7.net.xml");

            IEnumerable<XElement> net = xelement_ant.Elements();

            List<string> menuList_ant = new List<string>();
            List<string> subMenuList_ant = new List<string>();

            foreach (var menu in net)
            {
                try
                {
                    if (menu.Attribute("id").Value == "edge2a" || menu.Attribute("id").Value == "edge2b")
                    {
                        foreach (var submenu in menu.Elements())
                        {
                            subMenuList_ant.Add(submenu.Attribute("speed").Value = edge2_speed);
                        }
                    }

                    if (menu.Attribute("id").Value == "edge5a" || menu.Attribute("id").Value == "edge5b")
                    {
                        foreach (var submenu in menu.Elements())
                        {
                            subMenuList_ant.Add(submenu.Attribute("speed").Value = edge5_speed);
                        }
                    }

                    if (menu.Attribute("id").Value == "edge8a" || menu.Attribute("id").Value == "edge8b")
                    {
                        foreach (var submenu in menu.Elements())
                        {
                            subMenuList_ant.Add(submenu.Attribute("speed").Value = edge8_speed);
                        }
                    }

                    if (menu.Attribute("id").Value == "edge11a" || menu.Attribute("id").Value == "edge11b")
                    {
                        foreach (var submenu in menu.Elements())
                        {
                            subMenuList_ant.Add(submenu.Attribute("speed").Value = edge11_speed);
                        }
                    }
                }

                catch (Exception)
                { }

                xelement_ant.Save(@"H:\Thesis\VS17\Sumo_XML\Thesis\Sample Map Antcolony Normal\test7.net.xml");
            }
        }

        public void sumoGuiFunction()
        {
            process = new Process();
            process.StartInfo.FileName = "cmd.exe";
            process.StartInfo.CreateNoWindow = true;
            process.StartInfo.RedirectStandardInput = true;
            process.StartInfo.RedirectStandardOutput = true;
            process.StartInfo.UseShellExecute = false;
            process.Start();
            process.StandardInput.WriteLine("h:");
            process.StandardInput.WriteLine(@"cd H:\Thesis\VS17\Sumo_XML\Thesis\Sample Map Antcolony Normal");
            process.StandardInput.WriteLine("sumo-gui --routing-algorithm astar --start -c test7.sumocfg");
            process.StandardInput.Flush();
            process.StandardInput.Close();
        }

        public void latestFileAdding()
        {
            string Folder = @"H:\Thesis\VS17\Sumo_XML\Thesis\Sample Map Antcolony Normal";
            var files = new DirectoryInfo(Folder).GetFiles("test7_*.xml");
            string latestfile = "";

            DateTime lastupdated = DateTime.MinValue;

            foreach (FileInfo file in files)
            {
                if (file.LastWriteTime > lastupdated)
                {
                    lastupdated = file.LastWriteTime;
                    latestfile = file.Name;
                }
            }

            /// Latest File Load, Push, Save
            XElement xelement = XElement.Load(@"H:\Thesis\VS17\Sumo_XML\Thesis\Sample Map Antcolony Normal\test7.sumocfg");

            IEnumerable<XElement> configuration = xelement.Elements();

            List<string> menuList = new List<string>();
            List<string> subMenuList = new List<string>();

            int i = 0;

            foreach (var menu in configuration)
            {
                foreach (var submenu in menu.Elements())
                {
                    if (i == 2)
                    {
                        subMenuList.Add(submenu.Attribute("value").Value = latestfile);
                        break;
                    }
                    i++;
                }
                break;
            }
            xelement.Save(@"H:\Thesis\VS17\Sumo_XML\Thesis\Sample Map Antcolony Normal\test7.sumocfg");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            processTimer.Start();
            sumoGuiFunction();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Sample_Map_Antcolony sample_map_antcolony = new Sample_Map_Antcolony();
            sample_map_antcolony.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            foreach (var process_2 in Process.GetProcessesByName("sumo-gui"))
            {
                process_2.Kill();
                processTimer.Enabled = false;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            /// Reset Delay Time And Scheme In Sumo Gui Setting
            XElement xelement = XElement.Load(@"H:\Thesis\VS17\Sumo_XML\Thesis\Sample Map Antcolony Normal\gui-settings.cfg");

            IEnumerable<XElement> viewsettings = xelement.Elements();

            List<string> menuList = new List<string>();

            int i = 0;

            foreach (var menu in viewsettings)
            {
                try
                {
                    if (i == 0)
                    {
                        menuList.Add(menu.Attribute("value").Value = "150");
                    }
                    if (i == 1)
                    {
                        menuList.Add(menu.Attribute("name").Value = "real world");
                    }
                    i++;
                }

                catch (Exception)
                { }
            }

            /// Reset Load State Value In Sumo Configuartion File
            xelement.Save(@"H:\Thesis\VS17\Sumo_XML\Thesis\Sample Map Antcolony Normal\gui-settings.cfg");

            XElement xelement_2 = XElement.Load(@"H:\Thesis\VS17\Sumo_XML\Thesis\Sample Map Antcolony Normal\test7.sumocfg");

            IEnumerable<XElement> configuration = xelement_2.Elements();

            List<string> menuList2 = new List<string>();
            List<string> subMenuList = new List<string>();

            int j = 0;

            foreach (var menu in configuration)
            {
                try
                {

                    foreach (var submenu in menu.Elements())
                    {
                        if (j == 2)
                        {
                            subMenuList.Add(submenu.Attribute("value").Value = "");
                        }
                        j++;
                    }
                }

                catch (Exception)
                { }
            }
            xelement_2.Save(@"H:\Thesis\VS17\Sumo_XML\Thesis\Sample Map Antcolony Normal\test7.sumocfg");

            /// Delete Old State Files
            Process process = new Process();
            process.StartInfo.FileName = "cmd.exe";
            process.StartInfo.CreateNoWindow = true;
            process.StartInfo.RedirectStandardInput = true;
            process.StartInfo.RedirectStandardOutput = true;
            process.StartInfo.UseShellExecute = false;
            process.Start();
            process.StandardInput.WriteLine("h:");
            process.StandardInput.WriteLine(@"cd H:\Thesis\VS17\Sumo_XML\Thesis\Sample Map Antcolony Normal");
            ///process.StandardInput.WriteLine("Delete.bat");
            ///process.StandardInput.WriteLine("Delete2.bat");
            ///process.StandardInput.WriteLine("Delete3.bat");
            process.StandardInput.Flush();
            process.StandardInput.Close();
            process.WaitForExit();

            MessageBox.Show("Reset Successfully...");
            Sample_Map_Antcolony sample_map_antcolony = new Sample_Map_Antcolony();
            sample_map_antcolony.Show();
            this.Hide();
        }
    }
}
